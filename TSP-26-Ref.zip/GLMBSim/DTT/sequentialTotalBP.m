function [ estimatedTracks, estimatesFormat ] =  sequentialTotalBP( clutteredMeasurements, parameters )

numSteps = size(clutteredMeasurements, 1);
numParticles = parameters.numParticles;
falseAlarmDistribution = parameters.falseAlarmDistribution;
numSensors = parameters.numSensors;
meanClutterParameter = parameters.meanClutterParameter;
detectionProbability = parameters.detectionProbability;
measurementVarianceRange = parameters.measurementVarianceRange;
measurementVarianceBearing = parameters.measurementVarianceBearing;
detectionThreshold = parameters.detectionThreshold;
thresholdPruning = parameters.thresholdPruning;
scanTimes = parameters.scanTimes;
priorIntensity = parameters.birthProbability .* ...
    1 ./ ((parameters.surveillanceRegion(2, 1) - parameters.surveillanceRegion(1, 1)) ...
          .*(parameters.surveillanceRegion(2, 2) - parameters.surveillanceRegion(1, 2)));

estimates = cell(numSteps, 1);
estimatesFormat = cell(numSteps, 1);
posteriorBeliefs = zeros(4, numParticles, 0);
posteriorExistences = zeros(0, 1);
posteriorLabels = zeros(3, 0);
estimatedCardinality = zeros(numSteps, 1);

numTracksVector = zeros(numSteps, numSensors);

for step = 1 : numSteps
    [posteriorBeliefs,posteriorExistences] = performPrediction(posteriorBeliefs,posteriorExistences,scanTimes(step),parameters);

    
    for sensor = 1 : numSensors
        numTargets = size(posteriorBeliefs,3);
        numTracksVector(step,sensor) =  numTargets;    
        [newBeliefs,constants,newLabels,messagesNew] = generateNewBeliefs(clutteredMeasurements{step,sensor},sensor,step,priorIntensity*(1-detectionProbability)^(sensor-1),parameters);
        
        predictedRange = zeros(numParticles,numTargets);
        predictedBearing = zeros(numParticles,numTargets);
        for target = 1:numTargets
            % predictedRange(:,target) = sqrt((posteriorBeliefs(1,:,target) - sensorPositions(1,sensor)).^2+(posteriorBeliefs(2,:,target) - sensorPositions(2,sensor)).^2)';
            % predictedBearing(:,target) = atan2d(posteriorBeliefs(1,:,target) - sensorPositions(1,sensor), posteriorBeliefs(2,:,target) - sensorPositions(2,sensor))';
            predictedRange(:, target) = posteriorBeliefs(1, :, target);
            predictedBearing(:,target) = posteriorBeliefs(2, :, target);
        end
        [messages,~,messagesNew] = solveDataAssociation(clutteredMeasurements{step, sensor}, predictedRange, predictedBearing, posteriorExistences, messagesNew, parameters);
          
        
        for target = 1:numTargets
            constantFactor = 1/(2*pi*sqrt(measurementVarianceBearing*measurementVarianceRange))*detectionProbability/(meanClutterParameter*falseAlarmDistribution);
            
            measuremenents = clutteredMeasurements{step,sensor};
            [numMeasurements, ~] = size(measuremenents);
            weights = repmat((1-detectionProbability),numParticles,1);
            for measurement = 1:numMeasurements
                weights = weights + messages(measurement,target)*constantFactor*exp(-1/(2*measurementVarianceRange)*(measuremenents(measurement,1)-predictedRange(:,target)).^2).*exp(-1/(2*measurementVarianceBearing)*(measuremenents(measurement,2)-predictedBearing(:,target)).^2);
            end
            
            if(sum(weights))
                posteriorBeliefs(:,:,target) = posteriorBeliefs(:,resampleSystematic(1/sum(weights)*weights,numParticles),target);
                % posteriorBeliefs(:,:,target) = posteriorBeliefs(:,randsample(numParticles,numParticles,true,weights),target);
            end
            
            aliveUpdate = 1/(numParticles)*sum(weights);
            aliveTmp = posteriorExistences(target)*aliveUpdate;
            deadTmp = (1-posteriorExistences(target));
            posteriorExistences(target) = aliveTmp/(deadTmp+aliveTmp);
        end
        % merge new and legacuy tracks
        posteriorBeliefs = cat(3,posteriorBeliefs,newBeliefs);
        
        newExistences = messagesNew.*constants./(messagesNew.*constants + 1);
        posteriorExistences = cat(1,posteriorExistences,newExistences);
        posteriorLabels = cat(2,posteriorLabels,newLabels);
        
        % perform pruning
        numTargets = size(posteriorBeliefs,3);
        isRedundant = false(numTargets,1);
        for target = 1:numTargets
            if(posteriorExistences(target) < thresholdPruning)
                isRedundant(target) = true;
            end
        end
        posteriorBeliefs = posteriorBeliefs(:,:,~isRedundant);
        posteriorLabels =  posteriorLabels(:,~isRedundant);
        posteriorExistences = posteriorExistences(~isRedundant, :);
    end
    estimatedCardinality(step) = sum(posteriorExistences);
    % perform estimation
    numTargets = size(posteriorBeliefs,3);
    detectedTargets = 0;
    for target = 1:numTargets
        if(posteriorExistences(target) > detectionThreshold)
            detectedTargets = detectedTargets + 1;
            estimates{step}.state(:,detectedTargets) = mean(posteriorBeliefs(:,:,target),2);
            estimates{step}.label(:,detectedTargets) = posteriorLabels(:,target);
            % estimatesFormat{step}(detectedTargets, :) = mean(posteriorBeliefs(:,:,target),2);
            estimatesFormat{step}(detectedTargets, :) = [mean(posteriorBeliefs(:,:,target),2).', posteriorExistences(target)];
        end
    end
    if parameters.printResults
    	step
    	[permute(mean(posteriorBeliefs, 2), [1, 3, 2]); ...
     	posteriorExistences.']
    end
end
estimatedTracks = trackFormation(estimates, parameters);

end
