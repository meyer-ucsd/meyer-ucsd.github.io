function [angle] = angleFromParticles(particles, weights)
particles = wrapTo180(particles);
numParticles = length(particles);

signs = sign(particles);
if(sum(signs*signs(1)) ~= numParticles)
    totalWeightPositive = sum(weights(signs>=0));
    positiveMean = sum(particles(signs>=0).*weights(signs>=0)/totalWeightPositive);
    totalWeightNegative = sum(weights(signs<0));
    negativeMean = sum(particles(signs<0).*weights(signs<0)/totalWeightNegative);
    
    if((positiveMean - negativeMean) >= 180)
        negativeMean = negativeMean+360;
    end
    angle = positiveMean*totalWeightPositive+negativeMean*totalWeightNegative;
else
    angle = sum(particles.*weights);
end

angle = wrapTo180(angle);

end