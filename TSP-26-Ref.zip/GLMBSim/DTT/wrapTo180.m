function [ angleOutput ] = wrapTo180( angleInput )

while(sum(angleInput>180))
    angleInput(angleInput>180) = angleInput(angleInput>180)-360;
end

while(sum(angleInput<-180))
    angleInput(angleInput<-180) = angleInput(angleInput<-180)+360;
end

angleOutput = angleInput;

end

