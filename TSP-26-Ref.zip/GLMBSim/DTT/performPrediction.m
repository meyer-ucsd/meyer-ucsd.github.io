function [ newParticles, newExistences ] = performPrediction( oldParticles, oldExistences, scanTime, parameters )
[~,numParticles,numTargets] = size(oldParticles);
drivingNoiseVariance = parameters.drivingNoiseVariance;
survivalProbability = parameters.survivalProbability;

[A, W] = getTransitionMatrices(scanTime);
newParticles = oldParticles;
newExistences = oldExistences;

for target = 1:numTargets
    % newParticles(:,:,target) = A*oldParticles(:,:,target) + W*sqrt(drivingNoiseVariance)*randn(2,numParticles);
    newParticles(:,:,target) = A*oldParticles(:,:,target) ...
        + W * (sqrt(drivingNoiseVariance) .* randn(2,numParticles));
    newExistences(target) = survivalProbability*oldExistences(target);
end

end

