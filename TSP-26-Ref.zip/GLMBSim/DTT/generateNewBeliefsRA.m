function [newBeliefs,constants,newLabels,messagesNew] = generateNewBeliefs(newMeasurements,sensor,step,priorIntensity,parameters)
numParticles = parameters.numParticles;
detectionProbability = parameters.detectionProbability;
clutterIntensity = parameters.meanClutterParameter*parameters.falseAlarmDistribution;
sensorPosition = parameters.sensorPositions(:,sensor);
surveillanceRegion = parameters.surveillanceRegion;
measurementVarianceRange = parameters.measurementVarianceRange;
measurementVarianceBearing = parameters.measurementVarianceBearing;
priorVelocityCovariance = parameters.priorVelocityCovariance;
constantLikelihood = 1/(2*pi*sqrt(measurementVarianceBearing*measurementVarianceRange));
constantWeight = 1/((parameters.surveillanceRegion(1,1)-parameters.surveillanceRegion(2,1))*(parameters.surveillanceRegion(1,2)-parameters.surveillanceRegion(2,2)));

numMeasurements = size(newMeasurements,1);
newBeliefs = zeros(4,numParticles,numMeasurements);
newLabels = zeros(3,numMeasurements);
messagesNew = zeros(numMeasurements,1);
constants = zeros(numMeasurements,1);

for measurement = 1:numMeasurements
    
    particles = zeros(2,numParticles);

    % Sample particles from GMM birth model if available, otherwise uniform
    if isfield(parameters, 'model') && isfield(parameters.model, 'm_birth')
        % Vectorized GMM-based particle sampling (no for-loops)
        m_birth = parameters.model.m_birth;
        P_birth = parameters.model.P_birth;
        r_birth = parameters.model.r_birth;
        T_birth = parameters.model.T_birth;
        
        % Vectorized: select birth component for all particles at once
        compIndices = randsample(T_birth, numParticles, true, r_birth);
        
        % Vectorized: sample from each component using cellfun
        samplesPerComp = accumarray(compIndices(:), ones(numParticles,1), [T_birth, 1]);
        sampledParticles = cellfun(@(m, P, n) mvnrnd(m([1,3],1), P([1,3],[1,3],1), n(1))', ...
                                   m_birth, P_birth, num2cell(samplesPerComp), 'UniformOutput', false);
        
        % Concatenate all samples and reorder to match component indices
        allSamples = [sampledParticles{:}];
        [~, order] = sort(compIndices);
        particles = allSamples(:, order);
    else
        % Fallback: uniform sampling from surveillance region
        particles(1,:) = (surveillanceRegion(2,1)-surveillanceRegion(1,1))*rand(numParticles,1)+surveillanceRegion(1,1);
        particles(2,:) = (surveillanceRegion(2,2)-surveillanceRegion(1,2))*rand(numParticles,1)+surveillanceRegion(1,2);
    end

    predictedRange = sqrt((particles(1,:) - sensorPosition(1)).^2+(particles(2,:) - sensorPosition(2)).^2);
    predictedBearing = atan2(particles(2,:) - sensorPosition(2), particles(1,:) - sensorPosition(1));


    if ~parameters.useAdaptiveVar
        weights = ((-1/2)*(newMeasurements(measurement,1) - predictedRange).^2/(measurementVarianceRange)) + ((-1/2)*(wrapToPi(newMeasurements(measurement,2) - predictedBearing)).^2/(measurementVarianceBearing));
    else
                weights = ((-1/2)*(newMeasurements(measurement,1) - predictedRange).^2/(newMeasurements(measurement,3))) + ((-1/2)*(wrapToPi(newMeasurements(measurement,2) - predictedBearing)).^2/(newMeasurements(measurement,4)));
    end
        
    constants(measurement) = sum(1/numParticles*constantLikelihood*exp(weights));
    constants(measurement) = constants(measurement) / constantWeight;
    
    weights = weights - max(weights);
    weights = exp(weights);
    weights = weights/sum(weights);
    
    if(sum(weights))
        newBeliefs(1:2,:,measurement) = particles(:,resampleSystematic(weights,numParticles));
    else
        newBeliefs(1:2,:,measurement) = particles;
    end
    newBeliefs(3:4,:,measurement) = mvnrnd( [0;0], priorVelocityCovariance, numParticles )';
    % if (size(newMeasurements, 2) > 3)
    %     newBeliefs(3 : 4, :, measurement) = mvnrnd( [newMeasurements(measurement, 3); 0], priorVelocityCovariance, numParticles )';
    % end
    
    newLabels(:,measurement) = [step;sensor;measurement];
    messagesNew(measurement) = 1 + (constants(measurement) * priorIntensity) / clutterIntensity;
    
    constants(measurement) = constants(measurement) * priorIntensity / clutterIntensity;
end


end

