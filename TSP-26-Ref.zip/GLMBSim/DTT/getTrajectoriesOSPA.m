function [ ospaOut ] = getTrajectoriesOSPA( trueTrajectories, estimates, BPmode, parameters)
OSPAc = parameters.OSPAc;
OSPAp = parameters.OSPAp;
[~,numTimesteps, numTargets] = size(trueTrajectories);

ospaOut = zeros(numTimesteps,1);
for step = 1:numTimesteps
    
    if(BPmode)
        [~,~, numTracks] = size(estimates);
        ospaInput1 = [];
        for track = 1:numTracks
            if(~isnan(estimates(1,step,track)))
                ospaInput1 = [ospaInput1 estimates(:,step,track)];
            end
        end
    else
        ospaInput1 = estimates{step};
    end
    
    ospaInput2 = [];
    for target = 1:numTargets
        if(~isnan(trueTrajectories(1,step,target)))
            ospaInput2 = [ospaInput2 trueTrajectories(:,step,target)];
        end
    end
    ospaOut(step) = getOSPA(ospaInput2,ospaInput1,OSPAc,OSPAp);
end

end

