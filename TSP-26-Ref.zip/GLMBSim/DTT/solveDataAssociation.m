function [messagelhfRatios,associationProbabilitiesNew,messagelhfRatiosNew] = solveDataAssociation(measurements, predictedRange, predictedBearing, predictedExistence, newInputBP, parameters)
falseAlarmDistribution = parameters.falseAlarmDistribution;
threshold = parameters.thresholdBp;
numInnerIterations = parameters.numBpIterations;
measurementVarianceRange = parameters.measurementVarianceRange;
measurementVarianceBearing = parameters.measurementVarianceBearing;
meanClutterParameter = parameters.meanClutterParameter;
detectionProbability = parameters.detectionProbability;
numPoints = parameters.numParticles;
numTargets = length(predictedExistence);
[numMeasurements, ~] = size(measurements);

if(numTargets == 1)
    messagelhfRatios = ones(numMeasurements+1,1);
    messagelhfRatiosNew = ones(numMeasurements,1);
    associationProbabilitiesNew = ones(numMeasurements,1); 
elseif(numMeasurements == 0)
    messagelhfRatios = ones(1,numTargets);
    messagelhfRatiosNew = ones(0,1);
    associationProbabilitiesNew = ones(0,1); 
else
    inputBP = zeros(numMeasurements+1,numTargets);
    inputBP(1,:) = (1-detectionProbability);
    
    %calculate input for BP-based data association from likelihood
    constantFactor = 1/(2*pi*sqrt(measurementVarianceBearing*measurementVarianceRange))*detectionProbability/(meanClutterParameter*falseAlarmDistribution);
    % for target =  1:numTargets   
    %     for measurement = 1:numMeasurements
    %         inputBP(measurement+1,target) = 1/numPoints*constantFactor*sum( (exp(-1/(2*measurementVarianceRange)*(measurements(measurement,1)-predictedRange(:,target)).^2)) .* (exp(-1/(2*measurementVarianceBearing)*wrapTo180(measurements(measurement,2)-predictedBearing(:,target)).^2)) );
    %     end
    %     inputBP(:,target) = getInputBP(predictedExistence(target), inputBP(:,target));
    % end

    for measurement = 1:numMeasurements
        inputBP(measurement+1, :) = 1/numPoints*constantFactor*sum( (exp(-1/(2*measurementVarianceRange)*(measurements(measurement,1)-predictedRange).^2)) .* (exp(-1/(2*measurementVarianceBearing)*wrapTo180(measurements(measurement,2)-predictedBearing).^2)) );
    end
    inputBP = getInputBP(predictedExistence, inputBP);

    %perform BP-based data association
    [~,associationProbabilitiesNew,messagelhfRatios,messagelhfRatiosNew] = dataAssociationBP( inputBP, newInputBP, threshold, numInnerIterations );
end
end

function [ messageOut ] = getInputBP2( existence, messageTargetIsPresent)
[lenMessage, ~] = size(messageTargetIsPresent);

messageTargetIsAbsent = zeros(lenMessage,1);
messageTargetIsAbsent(1) = 1;

messageOut = existence*messageTargetIsPresent + (1-existence)*messageTargetIsAbsent;
end

function [ messageOut ] = getInputBP( existence, messageTargetIsPresent)
    messageTargetIsAbsent = zeros(size(messageTargetIsPresent));
    messageTargetIsAbsent(1, :) = 1;

    messageOut = messageTargetIsPresent .* existence' + messageTargetIsAbsent .* (1 - existence)';
end
