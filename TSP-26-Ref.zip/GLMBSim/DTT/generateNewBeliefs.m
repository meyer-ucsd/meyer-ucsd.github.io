function [newBeliefs,constants,newLabels,messagesNew] = generateNewBeliefs(newMeasurements,sensor,step,priorIntensity,parameters)
numParticles = parameters.numParticles;
detectionProbability = parameters.detectionProbability;
clutterIntensity = parameters.meanClutterParameter*parameters.falseAlarmDistribution;
% sensorPosition = parameters.sensorPositions(:,sensor);
surveillanceRegion = parameters.surveillanceRegion;
measurementVarianceRange = parameters.measurementVarianceRange;
measurementVarianceBearing = parameters.measurementVarianceBearing;
priorVelocityCovariance = parameters.priorVelocityCovariance;
constantLikelihood = 1/(2*pi*sqrt(measurementVarianceBearing*measurementVarianceRange));
constantWeight = 1/((parameters.surveillanceRegion(1,1)-parameters.surveillanceRegion(2,1))*(parameters.surveillanceRegion(1,2)-parameters.surveillanceRegion(2,2)));

numMeasurements = size(newMeasurements,1);
newBeliefs = zeros(4,numParticles,numMeasurements);
newLabels = zeros(3,numMeasurements);
messagesNew = zeros(numMeasurements,1);
constants = zeros(numMeasurements,1);

for measurement = 1:numMeasurements
    
    particles = zeros(2,numParticles);

    
    % particles(1, :) = newMeasurements(measurement, 1) + randn(1, numParticles) ...
    %     .* sqrt(measurementVarianceRange);
    % particles(2, :) = newMeasurements(measurement, 2) + randn(1, numParticles) ...
    %     .* sqrt(measurementVarianceBearing);

    % weights = zeros(1, numParticles);
    % constants(measurement) = sum( (particles(1, :) >= surveillanceRegion(1, 1)) ...
    %                               & (particles(1, :) <= surveillanceRegion(2, 1)) ...
    %                               & (particles(2, :) >= surveillanceRegion(1, 2)) ...
    %                               & (particles(2, :) <= surveillanceRegion(2, 2)), 2) ...
    %                               ./ numParticles

    particles(1,:) = (surveillanceRegion(2,1)-surveillanceRegion(1,1))*rand(numParticles,1)+surveillanceRegion(1,1);
    particles(2,:) = (surveillanceRegion(2,2)-surveillanceRegion(1,2))*rand(numParticles,1)+surveillanceRegion(1,2);
    
    predictedRange = particles(1, :);
    predictedBearing = particles(2, :);

    weights = ( (-1 / 2) * (newMeasurements(measurement,  1) - predictedRange) .^ 2 ...
                ./ (measurementVarianceRange)) ...
                + ((-1 / 2) * (newMeasurements(measurement, 2) - predictedBearing) .^ 2 ...
                   ./(measurementVarianceBearing));
    
    constants(measurement) = sum(1/numParticles*constantLikelihood*exp(weights));
    constants(measurement) = constants(measurement) / constantWeight;
    
    weights = weights - max(weights);
    weights = exp(weights);
    weights = weights/sum(weights);
    
    if(sum(weights))
        newBeliefs(1:2,:,measurement) = particles(:,resampleSystematic(weights,numParticles));
    else
        newBeliefs(1:2,:,measurement) = particles;
    end
    newBeliefs(3:4,:,measurement) = mvnrnd( [0;0], priorVelocityCovariance, numParticles )';
    % if (size(newMeasurements, 2) > 3)
    %     newBeliefs(3 : 4, :, measurement) = mvnrnd( [newMeasurements(measurement, 3); 0], priorVelocityCovariance, numParticles )';
    % end
    
    newLabels(:,measurement) = [step;sensor;measurement];
    messagesNew(measurement) = 1 + (constants(measurement) * priorIntensity) / clutterIntensity;
    
    constants(measurement) = constants(measurement) * priorIntensity / clutterIntensity;
end


end

