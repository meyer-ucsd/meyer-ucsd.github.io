function [targetTrajectory, trueCardinality ] = generateTrajectories(parameters,numSteps)
scanTimes = parameters.scanTimes;
drivingNoiseVariance = parameters.drivingNoiseVariance;
targetAppearanceFromTo = parameters.targetAppearanceFromTo;
targetStartStates = parameters.targetStartStates;
[~, numTargets] = size(targetStartStates);

targetTrajectory = nan(4,numSteps,numTargets);
for target = 1:numTargets
    tmp = targetStartStates(:,target);
    
    for step=2:numSteps
        [A, W] = getTransitionMatrices(scanTimes(step));        
        tmp = A*tmp + W*sqrt(drivingNoiseVariance)*randn(2,1);
        if(targetAppearanceFromTo(1,target) <= step && step <= targetAppearanceFromTo(2,target))
        targetTrajectory(:,step,target) = tmp;
        end
    end
end
trueCardinality = sum(~isnan(targetTrajectory(1,:,:)),3);
end

