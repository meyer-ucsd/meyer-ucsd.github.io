function [ospa] = evaluation(trueTracks,tracks,parameters)
OSPAc = parameters.OSPAc;
OSPAp = parameters.OSPAp;
[~,numSteps,~] = size(tracks);

ospa = zeros(numSteps,1);
for step = 1:numSteps
    targetStates = squeeze(trueTracks(:,step,:));
    targetStates = targetStates(:,~isnan(targetStates(1,:)));
    
    estimatedStates = squeeze(tracks(:,step,:));
    estimatedStates = estimatedStates(:,~isnan(estimatedStates(1,:)));
    
%     numStates = size(estimatedStates,2);
%     if(numStates > 8)
%        estimatedStates = estimatedStates(:,1:8);
%     end
    ospa(step) = getOSPA(estimatedStates, targetStates, OSPAc, OSPAp);
end

end

