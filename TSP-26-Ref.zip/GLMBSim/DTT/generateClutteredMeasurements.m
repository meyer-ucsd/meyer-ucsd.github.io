function [clutteredMeasurements] = generateClutteredMeasurements(correctMeasurements, parameter)
detectionProbability = parameter.detectionProbability;
numSensors = parameter.numSensors;
meanClutterParameter = parameter.meanClutterParameter;
measurementRange = parameter.measurementRange;
[~, timeSteps, numTargets, ~] = size(correctMeasurements);
maxMeasurements = inf;

clutteredMeasurements = cell(timeSteps,numSensors);

for step = 1:timeSteps
    for sensor = 1:numSensors
    
        detectionIndicator = logical((rand(numTargets,1) < detectionProbability) .* squeeze(~isnan(correctMeasurements(1,step,:,sensor))));
        detectedMeasurements = squeeze(correctMeasurements(:,step,detectionIndicator,sensor))';
        
        numFalseAlarms = poissrnd(meanClutterParameter);
        
        tmp = zeros(numFalseAlarms,2);
        tmp(:,1) = rand(numFalseAlarms,1)*measurementRange;
        tmp(:,2) = 360*rand(numFalseAlarms,1)-180;
        
        tmp = [tmp; detectedMeasurements];
        [numMeasurements,~] = size(tmp);
        tmp = tmp(randperm(numMeasurements),:);
        
        clutteredMeasurements{step,sensor} = tmp;    
    end
end

end

