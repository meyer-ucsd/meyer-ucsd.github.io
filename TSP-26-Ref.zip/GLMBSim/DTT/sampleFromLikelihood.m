function [ samples ] = sampleFromLikelihood(measurement, sensorIndex, numParticles, parameters)
sensorPosition = parameters.sensorPositions(:,sensorIndex);
measurementVarianceRange = parameters.measurementVarianceRange;
measurementVarianceBearing = parameters.measurementVarianceBearing;
priorVelocityCovariance = parameters.priorVelocityCovariance;

samples = zeros(4,numParticles);

randomRange = measurement(1)+sqrt(measurementVarianceRange)*randn(1,numParticles);
randomBearing = measurement(2)+sqrt(measurementVarianceBearing)*randn(1,numParticles);
samples(1:2,:) = [sensorPosition(1) + randomRange.*sind(randomBearing); sensorPosition(2) + randomRange.*cosd(randomBearing)];
samples(3:4,:) = mvnrnd( [0;0], priorVelocityCovariance, numParticles )';

end

