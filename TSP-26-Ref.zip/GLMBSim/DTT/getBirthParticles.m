function [ birthParticles, birthWeigths ] = getBirthParticles(oldMeasurements, scanTime, parameters)
numParticles = parameters.numBirthParticlesPHD;
drivingNoiseVariance = parameters.drivingNoiseVariance;
birthProbability = parameters.birthProbability;
surveillanceRegion = parameters.surveillanceRegion;
[A, W] = getTransitionMatrices(scanTime);
birthVelocityCovariance = parameters.priorVelocityCovariance;

[numMeasurements, ~] = size(oldMeasurements);
numParticlesPerMeasurement = ceil(numParticles/numMeasurements);

if(numMeasurements>0)
    birthParticles = zeros(4,numParticlesPerMeasurement,numMeasurements);
    for measurement = 1:numMeasurements        
        birthParticles(:,:,measurement) = sampleFromLikelihood(oldMeasurements(measurement,:), 1, numParticlesPerMeasurement, parameters);
    end
    birthParticles = reshape(birthParticles,[4,numParticlesPerMeasurement*numMeasurements]);
    birthParticles = birthParticles(:,randperm(numParticlesPerMeasurement*numMeasurements));
    birthParticles = birthParticles(:,1:numParticles);
    birthParticles = A*birthParticles + W*sqrt(drivingNoiseVariance)*randn(2,numParticles); 
else
    lengthX = surveillanceRegion(2,1)-surveillanceRegion(1,1); 
    lengthY = surveillanceRegion(2,2)-surveillanceRegion(1,2); 
    
    birthParticles = [ lengthX * rand(1, numParticles) + surveillanceRegion(1, 1); ...
                       lengthY * rand(1, numParticles) + surveillanceRegion(1, 2); ...
                       mvnrnd([0; 0], birthVelocityCovariance, numParticles)'];
end

birthWeigths = 1/numParticles*birthProbability*ones(numParticles,1);
end

