addpath '../'
clear variables; close all; clc; rng(1); 
pauseTime = 1;
numSteps = 150;

% main parameter
parameters.drivingNoiseVariance = 0.010;
parameters.measurementVarianceRange = 25^2;
parameters.measurementVarianceBearing = .5^2;
parameters.meanClutterParameter = 20;
parameters.detectionProbability = .9;
parameters.surveillanceRegion = [[-3000; 3000] [-3000; 3000]];
parameters.measurementRange = 2*parameters.surveillanceRegion(2,2);
parameters.falseAlarmDistribution = 1/(360*parameters.measurementRange);
parameters.numSensors = 1;
parameters.scanTimes = ones(numSteps,1);
parameters.priorVelocityCovariance = diag([10^2;10^2]);
parameters.survivalProbability = 0.999;
parameters.birthProbability = 0.01;
parameters.OSPAc = 200;
parameters.OSPAp = 1;

% BPbased filter related parameters
parameters.numParticles = 30000;
parameters.thresholdBp = 10^(-5);
parameters.numBpIterations = 10^(5);
parameters.detectionThreshold = .5;
parameters.thresholdPruning = 1e-4;
parameters.minimumTrackLength = 1;
parameters.calculateOSPA = true;

% generate trajectory and define sensor positions
parameters.targetStartStates = getStartStates( 3, 1000, 10 );
parameters.targetAppearanceFromTo = [[5;155],[10;160],[15;165],[20;170],[25;175],[30;180],[35;185],[40;190],[45;195],[50;200]] + 10;
[~, numTargets] = size(parameters.targetStartStates);
trajetories = generateTrajectories(parameters, numSteps);
parameters.sensorPositions = getSensorPositions( parameters.numSensors, 5000);

% generate measurements
measurements = generateMeasurements(trajetories, parameters);

% generate cluttered measurements
clutteredMeasurements = generateClutteredMeasurements(measurements, parameters);

tic
[ estimatedTrajectory, estimatedCardinality, ospa ] = sequentialTotalBP( clutteredMeasurements, trajetories, parameters );
toc
ospa = mean(ospa,2);
mean(ospa)

plotTrajectories(trajetories, estimatedTrajectory, parameters.sensorPositions, clutteredMeasurements, ospa, estimatedCardinality, 1);
sensorPositions = parameters.sensorPositions;
