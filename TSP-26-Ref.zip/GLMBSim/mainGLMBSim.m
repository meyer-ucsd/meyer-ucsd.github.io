% This is a demo script for the Generalized Labeled Multi-Bernoulli filter proposed in
% B.-T. Vo, and B.-N. Vo, "Labeled Random Finite Sets and Multi-Object Conjugate Priors," IEEE Trans. Signal Processing, Vol. 61, No. 13, pp. 3460-3475, 2013.
% http://ba-ngu.vo-au.com/vo/VV_Conjugate_TSP13.pdf
% with corresponding implementation details given in
% B.-N. Vo, B.-T. Vo, and D. Phung, "Labeled Random Finite Sets and the Bayes Multi-Target Tracking Filter," IEEE Trans. Signal Processing, Vol. 62, No. 24, pp. 6554-6567, 2014
% http://ba-ngu.vo-au.com/vo/VVP_GLMB_TSP14.pdf
%
% Modified to output results compatible with plotGOSPA.py
% Outputs: obj_pos_all (ground truth), outputCell (estimates) in cell array format
%

clear all;
close all;
rng(1);
addpath('./rfs_tracking_toolbox/glmb/smc');

%% Parameters
num_runs = 20;  % Number of Monte Carlo runs
num_steps_per_run = 100;  % Timesteps per run (will be determined by gen_truth)
max_num_objects = 10;  % Maximum number of objects for pre-allocation

% Initialize output data structures
obj_pos_all = NaN(2, max_num_objects, num_steps_per_run, num_runs);  % Ground truth: [x, y]
outputCell = cell(num_steps_per_run, num_runs);  % Estimates: cell(num_steps, num_runs)
measCell = cell(num_steps_per_run, num_runs);  % Measurements: cell(num_steps, num_runs)

% Generate model
model = gen_model;

%% Monte Carlo simulation loop
for run_idx = 1 : num_runs
    fprintf('Run %d / %d\n', run_idx, num_runs);
    
    % Generate truth and measurements for this run
    truth = gen_truth(model);
    meas = gen_meas(model, truth);
    
    % Run GLMB filter
    est = run_filter(model, meas);
    
    % Store measurements
    for step_idx = 1 : truth.K
        if ~isempty(meas.Z{step_idx})
            measCell{step_idx, run_idx} = meas.Z{step_idx}.';  % Transpose to [num_meas x 2]
        else
            measCell{step_idx, run_idx} = [];
        end
    end
    
    % Extract number of time steps from this run
    num_steps = truth.K;
    
    %% Extract ground truth positions (x, y only)
    for step_idx = 1 : num_steps
        if ~isempty(truth.X{step_idx})
            num_targets = size(truth.X{step_idx}, 2);
            % Extract x (row 1) and y (row 3) positions from state vector
            % State vector: [x; vx; y; vy; turn_rate]
            obj_pos_all([1, 2], 1:num_targets, step_idx, run_idx) = truth.X{step_idx}([1, 3], :);
        end
    end
    
    %% Extract GLMB filter estimates
    for step_idx = 1 : num_steps
        if ~isempty(est.X{step_idx})
            % est.X{k} is [5 x N(k)]: [x; vx; y; vy; turn_rate]
            % Reorder and transpose to [N(k) x 5]: [x; y; vx; vy; turn_rate]
            est_state = est.X{step_idx}([1, 3, 2, 4, 5], :).';
            outputCell{step_idx, run_idx} = est_state;
        else
            % Empty estimate (no targets detected)
            outputCell{step_idx, run_idx} = [];
        end
    end
end

%% Save results to file
% Save ground truth to data folder (where plotGOSPA.py expects it)
data_dir = './data/';
if ~exist(data_dir, 'dir')
    mkdir(data_dir);
end

gt_filename = [data_dir, 'gt_glmb_sim.mat'];
save(gt_filename, 'obj_pos_all');
fprintf('Ground truth saved to: %s\n', gt_filename);
fprintf('obj_pos_all shape: [%d, %d, %d, %d]\n', size(obj_pos_all));

% Save GLMB estimates and measurements to results folder
output_dir = './results/';
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

glmb_filename = [output_dir, 'results_glmb_sim.mat'];
save(glmb_filename, 'outputCell', 'measCell', 'num_runs', 'model');
fprintf('GLMB results saved to: %s\n', glmb_filename);
fprintf('outputCell shape: [%d, %d]\n', size(outputCell));
fprintf('measCell shape: [%d, %d]\n', size(measCell));
